<?php return array (
  'navadmin' => 'App\\Http\\Livewire\\Navadmin',
  'navsuper' => 'App\\Http\\Livewire\\Navsuper',
);