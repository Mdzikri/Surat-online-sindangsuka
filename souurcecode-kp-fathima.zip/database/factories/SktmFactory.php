<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Sktm;
use Faker\Generator as Faker;

$factory->define(Sktm::class, function (Faker $faker) {
    return [
        //
    ];
});
