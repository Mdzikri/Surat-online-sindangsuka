<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Sd;
use Faker\Generator as Faker;

$factory->define(Sd::class, function (Faker $faker) {
    return [
        //
    ];
});
