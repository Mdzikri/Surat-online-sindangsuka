<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PesanPenolakan;
use Faker\Generator as Faker;

$factory->define(PesanPenolakan::class, function (Faker $faker) {
    return [
        //
    ];
});
