<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Kades;
use Faker\Generator as Faker;

$factory->define(Kades::class, function (Faker $faker) {
    return [
        //
    ];
});
