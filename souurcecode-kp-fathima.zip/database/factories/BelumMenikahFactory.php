<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\BelumMenikah;
use Faker\Generator as Faker;

$factory->define(BelumMenikah::class, function (Faker $faker) {
    return [
        //
    ];
});
