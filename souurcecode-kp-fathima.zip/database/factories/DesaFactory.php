<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Desa;
use Faker\Generator as Faker;

$factory->define(Desa::class, function (Faker $faker) {
    return [
        //
    ];
});
