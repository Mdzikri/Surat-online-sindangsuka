<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Ajuan;
use Faker\Generator as Faker;

$factory->define(Ajuan::class, function (Faker $faker) {
    return [
        //
    ];
});
