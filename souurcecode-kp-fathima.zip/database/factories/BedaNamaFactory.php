<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\BedaNama;
use Faker\Generator as Faker;

$factory->define(BedaNama::class, function (Faker $faker) {
    return [
        //
    ];
});
