<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Sktb;
use Faker\Generator as Faker;

$factory->define(Sktb::class, function (Faker $faker) {
    return [
        //
    ];
});
