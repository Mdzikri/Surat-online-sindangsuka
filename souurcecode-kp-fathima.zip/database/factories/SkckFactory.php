<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Skck;
use Faker\Generator as Faker;

$factory->define(Skck::class, function (Faker $faker) {
    return [
        //
    ];
});
