<?php

use Illuminate\Database\Seeder;

class BelumMenikahSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
