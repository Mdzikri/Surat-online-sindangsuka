<?php

use Illuminate\Database\Seeder;

class BedaNamaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
