<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PesanPenolakan extends Model
{
    protected $fillable = ['isi'];
}
