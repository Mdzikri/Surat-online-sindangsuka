<?php

namespace App\Http\Controllers\Ajuan;

use App\MohonKtp;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MohonKtpController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(MohonKtp $mohonKtp)
    {
        //
    }

    public function edit(MohonKtp $mohonKtp)
    {
        //
    }

    public function update(Request $request, MohonKtp $mohonKtp)
    {
        //
    }

    public function destroy(MohonKtp $mohonKtp)
    {
        //
    }
}
