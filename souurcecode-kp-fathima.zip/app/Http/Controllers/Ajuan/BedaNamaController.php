<?php

namespace App\Http\Controllers\Ajuan;

use App\BedaNama;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BedaNamaController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(BedaNama $bedaNama)
    {
        //
    }

    public function edit(BedaNama $bedaNama)
    {
        //
    }

    public function update(Request $request, BedaNama $bedaNama)
    {
        //
    }

    public function destroy(BedaNama $bedaNama)
    {
        //
    }
}
