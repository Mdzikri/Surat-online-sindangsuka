<?php

namespace App\Http\Controllers\Ajuan;

use App\BelumMenikah;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BelumMenikahController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(BelumMenikah $belumMenikah)
    {
        //
    }

    public function edit(BelumMenikah $belumMenikah)
    {
        //
    }

    public function update(Request $request, BelumMenikah $belumMenikah)
    {
        //
    }

    public function destroy(BelumMenikah $belumMenikah)
    {
        //
    }
}
