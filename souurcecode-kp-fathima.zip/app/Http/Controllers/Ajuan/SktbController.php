<?php

namespace App\Http\Controllers\Ajuan;

use App\Sktb;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SktbController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(Sktb $sktb)
    {
        //
    }

    public function edit(Sktb $sktb)
    {
        //
    }

    public function update(Request $request, Sktb $sktb)
    {
        //
    }

    public function destroy(Sktb $sktb)
    {
        //
    }
}
