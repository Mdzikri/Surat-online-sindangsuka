<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link href="<?php echo e(asset('images/favicon.png')); ?>" rel="icon" type="image/png">

    <title>Suket Desa Sindangsuka</title>
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg costum-nav navbar-dark bg-oren px-4 py-3 shadow">
      <a class="navbar-brand" href="#">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo kabupaten garut">
        <span>Suket Online</span>
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('login')); ?>">Masuk <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link tombol-2 shadow" href="<?php echo e(route('register')); ?>">Daftar</a>
          </li>
        </ul>
      </div>
    </nav>
    

    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/layouts/auth.blade.php ENDPATH**/ ?>