

<?php $__env->startSection('content'); ?>
        <h1>Antrian Surat</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/admin/antrian.blade.php ENDPATH**/ ?>