<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    
    
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/surat-saya.css')); ?>">
    <link href="<?php echo e(asset('images/favicon.png')); ?>" rel="icon" type="image/png">

    <title>Suket Desa Sindangsuka</title>
    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg costum-nav navbar-dark bg-oren px-4 py-3 shadow">
      <a class="navbar-brand" href="#">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo kabupaten garut">
        <span>Suket Online</span>
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
              <a id="navbarDropdown" class="nav-link dropdown-toggle <?php echo e(request()->is('sku', 'sk', 'sktm', 'skck', 'sd') ? 'text-dark' : ''); ?>" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                  Ajukan Surat
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="<?php echo e(route('skck.create')); ?>">
                      SKCK
                  </a>
                  <a class="dropdown-item" href="<?php echo e(route('sktm.create')); ?>">
                      SKTM
                  </a>
                  <a class="dropdown-item" href="<?php echo e(route('sd.create')); ?>">
                      Surat Domisili
                  </a>
                  <a class="dropdown-item" href="<?php echo e(route('sk.create')); ?>">
                      Surat Kematian
                  </a>
                  <a class="dropdown-item" href="<?php echo e(route('sku.create')); ?>">
                      Surat Keterangan Usaha
                  </a>
              </div>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('surat-saya') ? 'text-dark' : ''); ?>" href="<?php echo e(route('suratsaya')); ?>">Surat Saya</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('lengkapi-profil') ? 'text-dark' : ''); ?>" href="<?php echo e(route('lengkapi.profil')); ?>">Lengkapi Profil</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('edit-profil') ? 'text-dark' : ''); ?>" href="<?php echo e(route('edit.profil')); ?>">Edit Profil</a>
          </li>
          <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
            </li>
            <?php if(Route::has('register')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                </li>
            <?php endif; ?>
          <?php else: ?>
              <li class="nav-item dropdown">
                  <a id="navbarDropdown" class="tombol-3 nav-link dropdown-toggle shadow" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                      <?php echo e(Auth::user()->nama); ?>

                  </a>
                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                         onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();">
                          Keluar
                      </a>
                      <a class="dropdown-item" href="<?php echo e(route('edit.profil')); ?>">
                          Pengaturan Akun
                      </a>
                      <?php if(auth()->check() && auth()->user()->hasRole('admin|superadmin')): ?>
                      <a class="dropdown-item" href="<?php echo e(route('antrian.index')); ?>">
                          Dashboard Admin
                      </a>
                      <?php endif; ?>
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                          <?php echo csrf_field(); ?>
                      </form>
                  </div>
              </li>
          <?php endif; ?>
        </ul>
      </div>
    </nav>
    
    <div class="nav-scroller bg-oren3 shadow-sm">
      <nav class="nav nav-underline">
        <a class="nav-link" href="<?php echo e(route('suratsaya')); ?>">Semua</a>
        <a class="nav-link" href="<?php echo e(route('menunggu')); ?>">Menunggu Persetujuan</a>
        <a class="nav-link" href="<?php echo e(route('diterima')); ?>">Diterima</a>
        <a class="nav-link active" href="<?php echo e(route('ditolak')); ?>">Ditolak</a>
      </nav>
    </div>
    <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php if(count($adatolak) != 0): ?>
    <main role="main" class="container">
      <div class="my-3 p-3 bg-white rounded shadow-sm">
        <h6 class="border-bottom border-gray pb-2 mb-0">Surat Tertolak</h6>
        <?php $__currentLoopData = $adatolak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ajuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="media text-muted pt-3">
            <svg class="bd-placeholder-img mr-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 32x32"><title>Placeholder</title><rect width="100%" height="100%" fill="#cc3300"/><text x="50%" y="50%" fill="#cc3300" dy=".3em">32x32</text></svg>
            <div class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
              <div class="d-flex justify-content-between align-items-center w-100">
                <strong class="text-gray-dark"><?php echo e($ajuan->jenis); ?></strong>
                  <a class="badge badge-danger">Ditolak</a>
              </div>
                <span class="d-block"> ditolak <?php echo e($ajuan->updated_at->format('d M Y')); ?> <b>&middot;</b> <a href="" data-toggle="modal" data-target="#pesanPenolakan<?php echo e($ajuan->id); ?>" class="text-primary">Lihat</a> | <a href="<?php echo e(route('home')); ?>" class="text-warning">Ajukan Kembali</a> </span>
            </div>
          </div>
          <!-- Modal Pesan Penolakan -->
                <div class="modal fade" id="pesanPenolakan<?php echo e($ajuan->id); ?>"  data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">Pesan penolakan dari admin</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <i><?php echo e($ajuan->pesan_penolakan); ?></i>
                      </div>
                      <div class="modal-footer">
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Ajukan Kembali</a>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Mengerti</button>
                      </div>
                    </div>
                  </div>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <small class="d-block text-right mt-3">
          <a href="#">All updates</a>
        </small>
      </div>
    </main>
    <?php endif; ?>

    <?php if(count($adatolak) == 0): ?>
    <main role="main" class="container">
      <div class="my-3 p-3 bg-white rounded shadow-sm">
        <h6 class="border-bottom border-gray pb-2 mb-0">Menunggu Persetujuan</h6>
        <div class="container bg-oren3 py-4">
          <img class="mx-auto d-block" src="<?php echo e(asset('images/surat.png')); ?>" alt="" width="48%">
          <h4 class="toren text-center mb-2"><b>Anda tidak memiliki surat yang ditolak oleh pihak desa</b></h4>
          <button data-toggle="modal" data-target="#ajukanModal" class="btn tombol-kotak-biru mx-auto d-block mt-3">Ajukan Surat &raquo;</button>
        </div>
        <small class="d-block text-right mt-3">
          <a href="#">All updates</a>
        </small>
      </div>
    </main>
    <?php endif; ?>


    <footer class="my-5 text-muted text-center text-small">
      <p class="mb-1">&copy; 2020 - PKM UIN-Desa Sindang Suka</p>
      <ul class="list-inline">
        <li class="list-inline-item"><a href="#">Privacy</a></li>
        <li class="list-inline-item"><a href="#">Terms</a></li>
        <li class="list-inline-item"><a href="#">Support</a></li>
      </ul>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  </body>
</html>


<!-- Modal -->
<div class="modal fade" id="ajukanModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ajukan Surat</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h5 class="text-center">Pilih Surat yang Anda Butuhkan</h5>
        <div class="row d-flex justify-content-center">
          <a href="<?php echo e(route('skck.create')); ?>" class="btn tombol-kotak mx-1 my-1">SKCK</a>
          <a href="<?php echo e(route('sktm.create')); ?>" class="btn tombol-kotak mx-1 my-1">SKTM</a>
          <a href="<?php echo e(route('sd.create')); ?>" class="btn tombol-kotak mx-1 my-1">Surat Domisili</a>
          <a href="<?php echo e(route('sku.create')); ?>" class="btn tombol-kotak mx-1 my-1">Surat Keterangan Usaha</a>
          <a href="<?php echo e(route('sk.create')); ?>" class="btn tombol-kotak mx-1 my-1">Surat Kematian</a>
        </div>
        <hr>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/user/navbar-surat/ditolak.blade.php ENDPATH**/ ?>