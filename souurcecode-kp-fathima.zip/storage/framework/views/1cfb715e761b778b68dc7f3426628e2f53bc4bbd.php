
<?php $__env->startSection('judul', 'Kelola Format Surat'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-md-7 pr-1">
            <div class="container card">
                <div class="card-header">
                    <h5 class="card-category mt-2">Kelola Pesan Penolakan Pengajuan:</h5>
                    <div class="d-flex justify-content-between">
                        <h3 class="card-title">Pesan Penolakan Pengajuan</h3>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahPesanPenolakan">
                          Tambah
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered">
                            <thead class=" text-primary">
                                <th><b>Pesan Penolakan</b></th>
                                <th class="text-right"><b>Opsi</b></th>
                            </thead>
                            <tbody>
                              <?php $__currentLoopData = $pesan_penolakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><i><?php echo e($p->isi); ?></i></td>
                                <td class="text-right inline-block" width="22%">
                                  <button type="button" class="badge badge-warning" data-toggle="modal" data-target="#editPesanPenolakan<?php echo e($p->id); ?>">Edit</button>
                                  <!-- Modal -->
                                  <div class="modal fade" id="editPesanPenolakan<?php echo e($p->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                                    <div class="modal-dialog">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title" id="exampleModalLabel">Edit Pesan Penolakan</h5>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                        </div>
                                        <!-- Modal -->
                                        <div class="modal-body">
                                          <form action="<?php echo e(route('pesan-penolakan.update', $p->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('patch'); ?>
                                            <div class="form-group">
                                              <label for="isi">Isi Pesan</label>
                                              <textarea class="form-control" name="isi" id="isi" cols="30" rows="10" placeholder="cont: Mohon maaf, pengajuan anda tertolak dikarenakan anda tidak berdomisili di Desa Sindangsuka"><?php echo e($p->isi); ?></textarea>
                                            </div>
                                          </div>
                                          <div class="modal-footer">
                                            <button type="submit" class="btn btn-warning mr-1">Edit</button>
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                          </form>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <button type="button" class="badge badge-danger" data-toggle="modal" data-target="#hapusPesanPenolakan<?php echo e($p->id); ?>">Hapus</button>
                                  <!-- Modal -->
                                  <div class="modal fade" id="hapusPesanPenolakan<?php echo e($p->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title" id="exampleModalLabel">Hapus Pesan Penolakan</h5>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                        </div>
                                        <div class="modal-body text-center">
                                          Anda yakin ingin menghapus pesan penolakan dibawah ini? <br>
                                          <i class="text-secondary">"<?php echo e($p->isi); ?>"</i>
                                        </div>
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
                                          <form action="<?php echo e(route('pesan-penolakan.delete', $p->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger" type="submit">Hapus</button>
                                          </form>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-md-5 pl-1">
            <div class="container card">
                <div class="card-header">
                    <h5 class="card-category mt-2">Kelola keterangan pada surat:</h5>
                    <div class="d-flex justify-content-between">
                        <h3 class="card-title">Keterangan Surat</h3>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahKeperluan">
                          Tambah
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered">
                            <thead class=" text-primary">
                                <th><b>Keperluan</b></th>
                                <th class="text-right"><b>Opsi</b></th>
                            </thead>
                            <tbody>
                              <?php $__currentLoopData = $keperluan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($k->keperluan); ?></td>
                                <td class="text-right inline-block" width="22%">
                                  <button type="button" class="badge badge-warning" data-toggle="modal" data-target="#editKeperluan<?php echo e($k->id); ?>">Edit</button>
                                  <!-- Modal -->
                                  <div class="modal fade" id="editKeperluan<?php echo e($k->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                                    <div class="modal-dialog">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title" id="exampleModalLabel">Edit Keperluan</h5>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                        </div>
                                        <!-- Modal -->
                                        <div class="modal-body">
                                          <form action="<?php echo e(route('keperluan.update', $k->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('patch'); ?>
                                            <div class="form-group">
                                              <label for="keperluan">Nama Keperluan</label>
                                              <input type="text" class="form-control" id="keperluan" name="keperluan" placeholder="cont: Perlengkapan Administrasi" value="<?php echo e($k->keperluan); ?>" autofocus="">
                                            </div>
                                          </div>
                                          <div class="modal-footer">
                                            <button type="submit" class="btn btn-warning mr-1">Edit</button>
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                          </form>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <button type="button" class="badge badge-danger" data-toggle="modal" data-target="#hapuskeperluan<?php echo e($k->id); ?>">Hapus</button>
                                  <!-- Modal -->
                                  <div class="modal fade" id="hapuskeperluan<?php echo e($k->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title" id="exampleModalLabel">Hapus Keperluan</h5>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                        </div>
                                        <div class="modal-body text-center">
                                           Anda yakin ingin menghapus keperluan dibawah ini? <br>
                                          <i class="text-secondary">"<?php echo e($k->keperluan); ?>"</i>
                                        </div>
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
                                          <form action="<?php echo e(route('keperluan.delete', $k->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger" type="submit">Hapus</button>
                                          </form>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Modal -->
<div class="modal fade" id="tambahKeperluan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Keterangan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('keperluan.store')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="keperluan">Keperluan</label>
            <input type="text" class="form-control" id="keperluan" name="keperluan" placeholder="cont: Perlengkapan Administrasi" autocomplete="" autofocus>
          </div>
          
          <div class="d-flex text-right">
              <button type="submit" class="btn btn-primary">Tambah</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="tambahPesanPenolakan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Pesan Penolakan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('pesan-penolakan.store')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="isi">Isi Pesan</label>
            <textarea class="form-control" name="isi" id="isi" cols="30" rows="10" placeholder="cont: Mohon maaf, pengajuan anda tertolak dikarenakan anda tidak berdomisili di Desa Sindangsuka"></textarea>
          </div>
          <div class="d-flex text-right">
              <button type="submit" class="btn btn-primary">Tambah</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/admin/surat/index.blade.php ENDPATH**/ ?>