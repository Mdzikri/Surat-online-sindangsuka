<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">

    <title>Suket Desa Sindangsuka</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light costum-nav px-4 py-3 shadow">
      <a class="navbar-brand" href="#">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo kabupaten garut">
        <span>Sindangsuka</span>
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('skck.create')); ?>">SKCK</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('sktm.create')); ?>">SKTM</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('sk.create')); ?>">Surat Kematian</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('sku.create')); ?>">Surat Keterangan Usaha</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('sd.create')); ?>">Surat Domisili</a>
          </li>
          <?php if(Route::has('login')): ?>
          <li class="nav-item">
            <a class="nav-link tombol shadow" href="<?php echo e(route('register')); ?>">Daftar</a>
          </li>
          <?php else: ?>
          <?php endif; ?>
        </ul>
      </div>
    </nav>
    <img class="bg" src="<?php echo e(asset('img/bg.jpg')); ?>" alt="">
    <div class="container justify-content-center">
      <a class="sourcefreepik" href='https://www.freepik.com/vectors/woman'><small>pch.vector - www.freepik.com</small></a>
    </div>

    <div class="container">
      <div class="row section-utama">
        <div class="col-12 col-lg-12">
          <h4>Layanan</h4>
          <h2>Persuratan</h2>
          <h5>Desa Sindang Suka</h5>
          <p>Layanan Persuratan Online Desa Sindang Suka Kecamatan Cibatu Kabupaten Garut. Klik tombol masuk untuk membuat surat</p>

          <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
              <a href="<?php echo e(url('/home')); ?>" class="shadow">Mulai</a>
            <?php else: ?>
              <a href="<?php echo e(route('login')); ?>" class="shadow">Masuk</a>
            <?php endif; ?>
          <?php endif; ?>
          
              
            </div>
          </div>
        </div>
        

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\Users\Fathima Umar\Desktop\surat2\resources\views/welcome.blade.php ENDPATH**/ ?>