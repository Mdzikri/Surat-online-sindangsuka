<?php if(session('status')): ?>
<div class="alert <?php echo e(session('warna')); ?> alert-dismissible fade show" role="alert">
  <i><?php echo e(session('status')); ?></i>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?><?php /**PATH C:\Users\Fathima Umar\Desktop\wanakarya\resources\views/layouts/alert.blade.php ENDPATH**/ ?>