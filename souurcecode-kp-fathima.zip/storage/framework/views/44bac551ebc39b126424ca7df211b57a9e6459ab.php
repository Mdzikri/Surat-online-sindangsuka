
<?php $__env->startSection('judul', 'Kelola Kades'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
          <div class="col-md-7 pr-1">
            <div class="card">
              <div class="card-header">
                <h5 class="title">Edit Data Kepala Desa</h5>
              </div>
              <div class="card-body">
                <form action="<?php echo e(route('kades.update', $kades->id)); ?>" method="post">
                  <?php echo method_field('patch'); ?>
                  <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama') ?? $kades->nama); ?>">
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="col-md-6 pl-1">
                      <div class="form-group">
                        <label>NIK</label>
                        <input type="text" name="nik" class="form-control" value="<?php echo e(old('nik') ?? $kades->nik); ?>">
                        <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4 pr-1">
                      <div class="form-group">
                        <label>Jabatan</label>
                        <input type="text" name="jabatan" class="form-control" value="<?php echo e(old('jabatan') ?? $kades->jabatan); ?>">
                        <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="col-md-4 pr-1 pl-1">
                      <div class="form-group">
                        <label>Agama</label>
                        <input type="text" name="agama" class="form-control" value="<?php echo e(old('agama') ?? $kades->agama); ?>">
                        <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="col-md-4 pl-1">
                      <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <select class="form-control pb-2" id="exampleFormControlSelect1" name="jk" value="<?php echo e($kades->jk); ?>">
                          <option value="<?php echo e($kades->jk); ?>"><?php echo e($kades->jk); ?></option>
                          <option value="Laki-laki">Laki-laki</option>
                          <option value="Perempuan">Perempuan</option>
                        </select>
                        <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4 pr-1">
                      <div class="form-group">
                        <label>Periode</label>
                        <input type="text" name="periode" class="form-control" value="<?php echo e(old('periode') ?? $kades->periode); ?>">
                        <?php $__errorArgs = ['periode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="col-md-8 pl-1">
                      <div class="form-group">
                        <label>Tempat, Tanggal Lahir</label>
                        <input type="text" name="ttl" class="form-control" value="<?php echo e(old('ttl') ?? $kades->ttl); ?>">
                        <?php $__errorArgs = ['ttl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Alamat</label>
                        <input type="text" name="alamat" class="form-control" value="<?php echo e(old('alamat') ?? $kades->alamat); ?>">
                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  </div>
                  <button type="submit" class="btn btn-primary my-3">Simpan</button>
                </form>
              </div>
            </div>
            <div class="card pt-1">
              <div class="card-header pt-2">
                <h5 class="title">Lengkapi Foto Kepala Desa</h5>
              </div>
              <div class="card-body">
                <form action="<?php echo e(route('kades.foto', $kades->id)); ?>" method="post" enctype="multipart/form-data">
                  <?php echo method_field('patch'); ?>
                  <?php echo csrf_field(); ?>
                  <div class="">
                    <label for="fotokades">Foto Kades</label> <br>
                    <?php if($kades->fotokades): ?>
                      <img src="<?php echo e(asset('images/fotokades/'.$kades->fotokades.'')); ?>" alt="Kades <?php echo e($kades->nama); ?>" class="img-thumbnail" width="180px">
                    <?php endif; ?>
                    <input type="file" class="" id="fotokades" name="fotokades" value="<?php echo e($kades->fotokades); ?>">

                    <?php if($kades->fotokades): ?>
                      <small class="form-text text-muted">Klik tombol diatas untuk mengganti foto Kades.</small>
                    <?php else: ?>
                      <small class="form-text text-muted">Tambahkan Pas Foto Kades.</small>
                    <?php endif; ?>

                    <?php $__errorArgs = ['fotokades'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="">
                    <label for="ttdcap">Foto KTP</label> <br>
                    <?php if($kades->ttdcap): ?>
                      <img src="<?php echo e(asset('images/ttdcap/'.$kades->ttdcap.'')); ?>" alt="Cap dan Ttd <?php echo e($kades->nama); ?>" class="img-thumbnail" width="180px">
                    <?php endif; ?>

                    <input type="file" class="" id="ttdcap" name="ttdcap" value="<?php echo e($kades->ttdcap); ?>">

                    <?php if($kades->ttdcap): ?>
                      <small class="form-text text-muted">Klik tombol diatas untuk mengganti Ttd Kades.</small>
                    <?php else: ?>
                      <small class="form-text text-muted">Tambahkan Cap dan Ttd Kades.</small>
                    <?php endif; ?>
                    
                    <?php $__errorArgs = ['ttdcap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <button type="submit" class="btn btn-primary my-3">Simpan</button>
                </form>
              </div>
            </div>
          </div>
          <div class="col-md-5 pl-1">
            <div class="card card-kades">
              <div class="card-body">
                <div class="container text-center my-2">
                    <img src="<?php echo e(asset('storage/fotokades/'.$kades->fotokades)); ?>" class="rounded-circle" width="120px">
                </div>
                <h5 class="title text-center">Data Identitas</h5>
                <table border="0" align="center" width=83% style="padding-left: 30px;">
                    <tr>
                        <td class="text-secondary" width=28%>Nama</td>
                        <td class="text-secondary">:</td>
                        <td style="text-transform: uppercase;"><?php echo e($kades->nama); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Jabatan</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($kades->jabatan); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Periode</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($kades->periode); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Ttl</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($kades->ttl); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Alamat</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($kades->alamat); ?></td>
                    </tr>
                </table>
              </div>
              <hr>
              <div class="button-container text-center mb-3">
                <a href="" data-toggle="modal" data-target="#hapusKades<?php echo e($kades->id); ?>" class="btn btn-danger">Hapus Kades</a>
                <form action="<?php echo e(route('kades.aktifkan', $kades->id)); ?>" method="post" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-success">Aktifkan Kades</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

<!-- Modal Hapus Kades -->
<div class="modal fade" id="hapusKades<?php echo e($kades->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hapus Kepala Desa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p class="text-center">Anda yakin ingin menghapus <b><?php echo e($kades->nama); ?></b> dari <i> Data Kepala Desa Sindangsuka</i> ?</p>
        <small class="text-secondary text-center">*tindakan ini akan membuat <?php echo e($kades->nama); ?> tidak terdata lagi di data Kepala Desa Sindangsuka.</small>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
        <form action="<?php echo e(route('kades.delete', $kades->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('delete'); ?>
          <button class="btn btn-danger" type="submit">Hapus</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/super/kades/edit.blade.php ENDPATH**/ ?>