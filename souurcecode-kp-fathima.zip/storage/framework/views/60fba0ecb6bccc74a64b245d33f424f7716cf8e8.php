<!DOCTYPE html>
<html>

<head>
    <title>Document</title>
</head>

<body>
    <!-- KOP SURAT -->
    <table border="0" align="center" style="margin-top: 10px;" width=84%>
        <tr>
            <td width=14%><img src="<?php echo e(public_path('images/logo.png')); ?>" alt="" width="85" height="85">
            </td>
            <td>
                <center>
                    <font size="3">PEMERINTAH KABUPATEN GARUT</font>
                    <font size="3">KECAMATAN CIBATU</font> <br>
                    <font size="5"><b>DESA SINDANGSUKA</b></font> <br>
                    <font size="3"><i>Jalan Cibatu - Limbangan Nomor 1090</i></font>
                </center>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <hr style="border-width: medium; border-style: double;">
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <br>
                <center>
                    <font size="3"><b>SURAT KETERANGAN DOMISILI</b></font>
                    <hr width="180" style="border-width: thin; margin-top: 0px;">
                    <font size="3" style="line-height: 0.6;">NO. <?php echo e($ajuan->nosurat); ?></font>
                </center>
                <br>
            </td>
        </tr>
    </table>

    <table border="0" align="center" width=83%>
        <!-- KETERANGAN -->
        <tr>
            <td>
                <p style="text-align: justify;">
                    &nbsp;&nbsp;&nbsp;Yang bertanda tangan dibawah ini Kepala Desa Sindangsuka Kecamatan Cibatu
                    Kabupaten Garut, menerangkan bahwa :
                </p>
            </td>
        </tr>
    </table>

    <table border="0" align="center" width=83% style="padding-left: 30px;">
        <!-- IDENTITAS PENGAJU -->
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td style="text-transform: uppercase;"><?php echo e($user->nama); ?></td>
        </tr>
        <tr>
            <td>No NIK</td>
            <td>:</td>
            <td><?php echo e($user->nik); ?></td>
        </tr>
        <tr>
            <td>Tempat Tgl Lahir</td>
            <td>:</td>
            <td><?php echo e($user->ttl); ?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>:</td>
            <td><?php echo e($user->jk); ?></td>
        </tr>
        <tr>
            <td>Pekerjaan</td>
            <td>:</td>
            <td><?php echo e($user->pekerjaan); ?></td>
        </tr>
        <tr>
            <td>Kewarganegaraan</td>
            <td>:</td>
            <td><?php echo e($user->kewarganegaraan); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><?php echo e($user->alamat); ?></td>
        </tr>
    </table>

    <table border="0" align="center" width=83%>
        <!-- KETERANGAN -->
        <tr>
            <td>
                <p style="text-align: justify;">
                    &nbsp;&nbsp;&nbsp;Dengan ini menerangkan bahwa orang yang bersangkutan benar-benar berdomisili di
                    Desa Sindangsuka Kecamatan Cibatu Kabupaten Garut.
                </p>
            </td>
        </tr>
    </table>

    <table border="0" align="center" width=83%>
        <!-- KETERANGAN -->
        <tr>
            <td style="text-align: justify;">
                &nbsp;&nbsp;&nbsp;Surat keterangan ini diberikan untuk keperluan :
            </td>
        </tr>
        <tr>
            <td style="text-align: center; text-transform: uppercase;">
                <p>
                    <b><i><?php echo e($ajuan->keterangan); ?></i></b>
                </p>
            </td>
        </tr>
        <tr>
            <td style="text-align: justify;">
                &nbsp;&nbsp;&nbsp;Demikian surat keterangan ini kami buat dengan sebenarnya untuk selanjutnya dapat
                dipergunakan sebagaimana mestinya.
            </td>
        </tr>
    </table>

    <br><br>

    <table border="0" align="center" width=83%>
        <!-- KETERANGAN -->
        <tr>
            <td style="text-align: right;">
                Sindangsuka, <?php echo e($ajuan->updated_at->format('d F Y')); ?>

            </td>
        </tr>
        <tr>
            <td style="text-align: right; padding-right: 20px;">
                Kepala Desa Sindangsuka
            </td>
        </tr>
        <tr>
            <td style="text-align: right; ">
                <img src="<?php echo e(public_path('storage/ttdcap/'.$ajuan->ttd.'')); ?>" alt="" width="145">
            </td>
        </tr>
        <tr>
            <td style="text-align: right; padding-right: 53px;"><?php echo e($ajuan->kades); ?></td>
        </tr>
    </table>

</body>

</html><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/arsip/sd.blade.php ENDPATH**/ ?>