
<?php $__env->startSection('judul', 'Kelola User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="container card">
                <div class="card-header">
                    <h4 class="card-title">Daftar User Aktif</h4>
                    <h5 class="card-category mt-2">Penduduk yang telah registrasi</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered">
                            <thead class="text-primary">
                                <th><b>Nama Lengkap</b></th>
                                <th><b>Rt/Rw</b></th>
                                <th><b>Surat Ajuan</b></th>
                                <th class="text-right"><b>Opsi</b></th> 
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->status_verifikasi == 1): ?>
                                    <tr>
                                        <td><?php echo e($user->nama); ?></td>
                                        <td><?php echo e($user->rt->no); ?>/<?php echo e($user->rw->no); ?></td>
                                        <td>
                                            <?php if(count($user->ajuans) != 0): ?>
                                                <?php $__currentLoopData = $user->ajuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(route('antrian.edit', $aj->id)); ?>"><?php echo e($aj->jenis); ?></a>,
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            -
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-right">
                                            <a href="<?php echo e(route('user.show', $user->id)); ?>" class="badge badge-info">Lihat</a>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="container">
                    <?php echo e($users->links()); ?> 
                </div>
            </div>
            <div class="container card">
                <div class="card-header">
                    <h4 class="card-title">Daftar User Non-Aktif</h4>
                    <h5 class="card-category mt-2">Penduduk yang belum terverifikasi</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered">
                            <thead class="text-primary">
                                <th><b>Nama Lengkap</b></th>
                                <th><b>NIK</b></th>
                                <th><b>NO KK</b></th>
                                <th><b>Rt/Rw</b></th>
                                <th class="text-right"><b>Opsi</b></th> 
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->status_verifikasi == 0): ?>
                                    <tr>
                                        <td><?php echo e($user->nama); ?></td>
                                        <td><?php echo e($user->nik); ?></td>
                                        <td><?php echo e($user->no_kk); ?></td>
                                        <td><?php echo e($user->rt->no); ?>/<?php echo e($user->rw->no); ?></td>
                                        <td class="text-right">
                                            <a href="<?php echo e(route('user.show', $user->id)); ?>" class="badge badge-info">Lihat</a>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="container">
                    <?php echo e($users->links()); ?> 
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\wanakarya\resources\views/admin/user/index.blade.php ENDPATH**/ ?>