

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="py-5 text-center">
        <h2 class="orenjudul">Form Data Pengajuan SKCK</h2>
        <p class="birusubjudul">Harap isikan data dibawah ini sesuai dengan data pribadi anda.</p>
      </div>

    <div class="row mx-5 px-5">
      <div class="col-md-6 order-md-2 mb-4">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-muted">Identitas Penduduk</span>
          <span class="badge badge-secondary badge-pill">3</span>
        </h4>
        <ul class="list-group mb-3">
          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <h6 class="my-0">Nama Lengkap</h6>
              <!-- <small class="text-muted">Brief description</small> -->
            </div>
            <span class="text-muted"><?php echo e(user()->nama); ?></span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <h6 class="my-0">NIK</h6>
            </div>
            <span class="text-muted">NIK</span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <h6 class="my-0">Fakultas</h6>
            </div>
            <span class="text-muted">Sains & Teknologi</span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <h6 class="my-0">Tahun Lulus</h6>
            </div>
            <span class="text-muted">bulan taun</span>
          </li>
        </ul>
      </div>

      <div class="col-md-6 order-md-1">
        <h4 class="mb-3">Isi Data SKCK</h4>
        <form action="" method="post" class="needs-validation" novalidate>
            <div class="mb-3">
              <label for="agama">Agama</label>
              <input name="agama" type="text" class="form-control" id="agama" placeholder="" value="" required>
              <div class="invalid-feedback">
                wajib diisi.
              </div>
            </div>
            <div class="row">
              <div class="col-md-5 mb-3">
                <label for="country">Jenis Kelamin</label>
                <select name="jeniskelamin" class="custom-select d-block w-100 select" id="country">
                  <option value="">Laki-laki</option>
                  <option>Perempuan</option>
                </select>
                <div class="invalid-feedback">
                  Please select a valid country.
                </div>
              </div>
            </div>
            <div class="mb-3">
              <label for="pekerjaan">Pekerjaan</label>
              <input name="pekerjaan" type="text" class="form-control" id="pekerjaan" placeholder="" value="" required>
              <div class="invalid-feedback">
                wajib diisi.
              </div>
            </div>
            <div class="mb-3">
              <label for="keperluan">Keperluan</label>
              <input name="keperluan" type="text" class="form-control" id="keperluan" placeholder="" value="" required>
              <div class="invalid-feedback">
                wajib diisi.
              </div>
            </div>

          <hr class="mb-4">

          <h4 class="mb-3">Upload Berkas</h4>

          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="firstName">Foto KTP</label>
              <input type="file" id="firstName" placeholder="" value="" >
              <div class="invalid-feedback">
                wajib diisi.
              </div>
            </div>
            <div class="col-md-6 mb-3">
              <label for="lastName">Foto KK</label>
              <input type="file" id="lastName" placeholder="" value="" >
              <div class="invalid-feedback">
                wajib diisi.
              </div>
            </div>
          </div>

          <hr class="mb-4">
          <button class="btn btn-primary btn-lg btn-block tombol" type="submit" name="translate">Ajukan Permohonan Surat</button>
        </form>
      </div>
    </div>

      <footer class="my-5 pt-5 text-muted text-center text-small">
        <p class="mb-1">&copy; 2020 - Fathima Umar & Ahmad Kamal</p>
        <ul class="list-inline">
          <li class="list-inline-item"><a href="#">Privacy</a></li>
          <li class="list-inline-item"><a href="#">Terms</a></li>
          <li class="list-inline-item"><a href="#">Support</a></li>
        </ul>
      </footer>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\suketv7\resources\views/form-surat/skck.blade.php ENDPATH**/ ?>