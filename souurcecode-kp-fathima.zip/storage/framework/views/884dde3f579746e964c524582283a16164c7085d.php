<!DOCTYPE html>
<html>

<head>
    <title>Document</title>
    <link href="<?php echo e(isset($desa) ? public_path('images/' . $desa->logo_desa . '') : public_path('images/logo.png')); ?>" rel="icon" type="image/png">
</head>

<body>
    <!-- KOP SURAT -->
    <table border="0" align="center" style="margin-top: 10px;" width=84%>
        <tr>
            <td width=14%><img src="<?php echo e(isset($desa) ? public_path('images/' . $desa->logo_desa . '') : public_path('images/logo.png')); ?>" alt="" width="85" height="85">
            </td>
            <td>
                <center>
                    <font size="3" style="text-transform: uppercase">PEMERINTAH KABUPATEN <?php echo e(isset($desa) ? $desa->kabupaten : '*atur kabupaten'); ?></font>
                    <font size="3" style="text-transform: uppercase">KECAMATAN <?php echo e(isset($desa) ? $desa->kecamatan : '*atur kecamatan'); ?></font> <br>
                    <font size="5" style="text-transform: uppercase"><b>DESA <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?></b></font> <br>
                    <font size="3"><i><?php echo e(isset($desa) ? $desa->alamat_kantor : '*atur alamat kantor'); ?></i></font>
                </center>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <hr style="border-width: medium; border-style: double;">
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <br>
                <center>
                    <font size="3"><b>SURAT KETERANGAN BELUM MENIKAH</b></font>
                    <hr width="180" style="border-width: thin; margin-top: 0px;">
                    <font size="3" style="line-height: 0.6;">NO. <?php echo e($ajuan->nosurat); ?></font>
                </center>
                <br>
            </td>
        </tr>
    </table>

    <table border="0" align="center" width=83%>
        <!-- KETERANGAN -->
        <tr>
            <td>
                <p style="text-align: justify;">
                    &nbsp;&nbsp;&nbsp;Yang bertanda tangan dibawah ini Kepala Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?> Kecamatan <?php echo e(isset($desa) ? $desa->kecamatan : '*atur nama kecamatan'); ?>

                    Kabupaten <?php echo e(isset($desa) ? $desa->kabupaten : '*atur nama kabupaten'); ?>, menerangkan bahwa :
                </p>
            </td>
        </tr>
    </table>

    <table border="0" align="center" width=83% style="padding-left: 30px;">
        <!-- IDENTITAS PENGAJU -->
        <tr>
            <td width="35%">Nama</td>
            <td width="3%">:</td>
            <td style="text-transform: uppercase;"><?php echo e($user->nama); ?></td>
        </tr>
        <tr>
            <td>No Induk Kependudukan</td>
            <td>:</td>
            <td><?php echo e($user->nik); ?></td>
        </tr>
        <tr>
            <td>Nomor Kartu Keluarga</td>
            <td>:</td>
            <td><?php echo e($user->no_kk); ?></td>
        </tr>
        <tr>
            <td>Tempat, tanggal lahir</td>
            <td>:</td>
            <td><?php echo e($user->ttl); ?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin</td>
            <td>:</td>
            <td><?php echo e($user->jk); ?></td>
        </tr>
        <tr>
            <td>Agama</td>
            <td>:</td>
            <td><?php echo e($user->agama); ?></td>
        </tr>
        <tr>
            <td>Pendidikan</td>
            <td>:</td>
            <td><?php echo e($user->pendidikan); ?></td>
        </tr>
        <tr>
            <td>Pekerjaan</td>
            <td>:</td>
            <td><?php echo e($user->pekerjaan); ?></td>
        </tr>
        <tr>
            <td>Status Perkawinan</td>
            <td>:</td>
            <td><?php echo e($user->status); ?></td>
        </tr>
        <tr>
            <td>Nama Orang Tua</td>
            <td>:</td>
            <td style="text-transform: uppercase;"><?php echo e($user->nama_ayah); ?> / <?php echo e($user->nama_ibu); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><?php echo e($user->alamat); ?></td>
        </tr>
    </table>

    <table border="0" align="center" width=83%>
        <!-- KETERANGAN -->
        <tr>
            <td>
                <p style="text-align: justify;">
                    &nbsp;&nbsp;&nbsp;Dengan ini menerangkan bahwa orang yang bersangkutan benar-benar berdomisili di Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?> Kecamatan <?php echo e(isset($desa) ? $desa->kecamatan : '*atur nama kecamatan'); ?> dan sepengetahuan kami bahwa yang bersangkutan
                </p>
            </td>
        </tr>
    </table>

     <table border="0" align="center" width=83%>
        <tr>
            <td style="text-align: center; text-transform: uppercase;">
                <b style="text-transform: uppercase"><i>== belum pernah menikah ==</i></b>
            </td>
        </tr>
        <tr>
            <td style="text-align: justify;">
                Surat keterangan ini berlaku dari tanggal: <?php echo e($ajuan->updated_at->format('d F Y')); ?> hingga satu bulan kedepan. surat ini dipergunakan untuk : <?php echo e($ajuan->keterangan); ?>

            </td>
        </tr>
    </table>

    <br><br>

    <table border="0" align="center" width=83%>
        <!-- KETERANGAN -->
        <tr>
            <td style="text-align: right;">
                <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?>, <?php echo e($ajuan->updated_at->format('d F Y')); ?>

            </td>
        </tr>
        <tr>
            <td style="text-align: right; padding-right: 20px;">
                Kepala Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?>

            </td>
        </tr>
        <tr>
            <td style="text-align: right; ">
                <img src="<?php echo e(public_path('images/ttdcap/'.$ajuan->ttd.'')); ?>" alt="" width="145">
            </td>
        </tr>
        <tr>
            <td style="text-align: right; padding-right: 53px;"><?php echo e($ajuan->kades); ?></td>
        </tr>
    </table>

</body>

</html><?php /**PATH C:\Users\Fathima Umar\Desktop\wanakarya\resources\views/arsip/belum-menikah.blade.php ENDPATH**/ ?>