<!DOCTYPE html>
<html>

<head>
    <title>Document</title>
    <link href="<?php echo e(public_path('images/favicon.png')); ?>" rel="icon" type="image/png">
</head>

<body>
    <!-- KOP SURAT -->
    <table border="0" align="center" width=84%>
        <tr>
            <td width=14%><img src="<?php echo e(public_path('images/logo.png')); ?>" alt="" width="85" height="85">
            </td>
            <td>
                <center>
                    <font size="3">PEMERINTAH KABUPATEN GARUT</font>
                    <font size="3">KECAMATAN CIBATU</font> <br>
                    <font size="5"><b>DESA SINDANGSUKA</b></font> <br>
                    <font size="3"><i>Jalan Cibatu - Limbangan Nomor 1090</i></font>
                </center>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <hr style="border-width: medium; border-style: double;">
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <br>
                <center>
                    <font size="3"><b>SURAT KETERANGAN KEMATIAN</b></font>
                    <hr width="180" style="border-width: thin; margin-top: 0px;">
                    <font size="3" style="line-height: 0.6;">NO. <?php echo e($ajuan->nosurat); ?></font>
                </center>
                <br>
            </td>
        </tr>
    </table>

    <table border="0" align="center" width=83%>
        <!-- KETERANGAN -->
        <tr>
            <td>
                <p style="text-align: justify;">
                    Yang bertanda tangan di bawah ini, menerangkan bahwa :
                </p>
            </td>
        </tr>
    </table>

    <table border="0" align="center" width=83% style="padding-left: 0px;">
        <!-- IDENTITAS PENGAJU -->
        <thead>
            <tr>
                <td width=20%>Nama Lengkap</td>
                <td width=3%>:</td>
                <td style="text-transform: uppercase;"><?php echo e($ajuan->sk->nama_alm); ?></td>
            </tr>
        </thead>
        <tr>
            <td>Jenis Kelamin</td>
            <td>:</td>
            <td><?php echo e($ajuan->sk->jk_alm); ?></td>
        </tr>
        <tr>
            <td>Umur</td>
            <td>:</td>
            <td><?php echo e($ajuan->sk->umur_alm); ?></td>
        </tr>
        <tr>
            <td>Agama</td>
            <td>:</td>
            <td><?php echo e($ajuan->sk->agama_alm); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><?php echo e($ajuan->sk->alamat_alm); ?></td>
        </tr>
        <tr>
            <td colspan="3">
                <p style="text-align: justify;">Telah meninggal dunia pada :</p>
            </td>
        </tr>
        <tr>
            <td>Hari</td>
            <td>:</td>
            <td><?php echo e($ajuan->sk->hari); ?></td>
        </tr>
        <tr>
            <td>Tanggal</td>
            <td>:</td>
            <td><?php echo e($ajuan->sk->tanggal); ?></td>
        </tr>
        <tr>
            <td>Pukul</td>
            <td>:</td>
            <td><?php echo e($ajuan->sk->pukul); ?></td>
        </tr>
        <tr>
            <td>Tempat</td>
            <td>:</td>
            <td><?php echo e($ajuan->sk->tempat); ?></td>
        </tr>
        <tr>
            <td>Penyebab</td>
            <td>:</td>
            <td><?php echo e($ajuan->sk->penyebab); ?></td>
        </tr>
        <!-- PELAPOR -->
        <tr>
            <td colspan="3">
                <p style="text-align: justify;">Surat keterangan ini dibuat berdasarkan keterangan pelapor :</p>
            </td>
        </tr>
        <tr>
            <td>Nama Lengkap</td>
            <td>:</td>
            <td style="text-transform: uppercase;"><?php echo e($user->nama); ?></td>
        </tr>
        <tr>
            <td>Tanggal Lahir</td>
            <td>:</td>
            <td><?php echo e($user->ttl); ?></td>
        </tr>
        <tr>
            <td>Pekerjaan</td>
            <td>:</td>
            <td><?php echo e($user->pekerjaan); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><?php echo e($user->alamat); ?></td>
        </tr>
        <tr>
            <td>Penyebab</td>
            <td>:</td>
            <td><?php echo e($ajuan->sk->penyebab); ?></td>
        </tr>
        <tr>
            <td colspan="3">
                <p style="text-align: justify; display: inline;">Hubungan pelapor dengan yang meninggal : </p>
                <p style="text-transform: uppercase; display: inline;"><?php echo e($ajuan->sk->hubungan); ?></p>
            </td>
        </tr>
        <tr>
            <td colspan="3">
                <p style="text-align: justify;">Demikian surat kematian ini dibuat dengan sebenar-benarnya agar dapat
                    dipergunakan sebagaimana mestinya</p>
            </td>
        </tr>
    </table>

    <table border="0" align="center" width=83%>
        <!-- KETERANGAN -->
        <tr>
            <td style="text-align: right;">
                Sindangsuka, <?php echo e($ajuan->updated_at->format('d F Y')); ?>

            </td>
        </tr>
        <tr>
            <td style="text-align: right; padding-right: 20px;">
                Kepala Desa Sindangsuka
            </td>
        </tr>
        <tr>
            <td style="text-align: right; ">
                <img src="<?php echo e(public_path('storage/ttdcap/'.$ajuan->ttd.'')); ?>" alt="" width="145">
            </td>
        </tr>
        <tr>
            <td style="text-align: right; padding-right: 53px;"><?php echo e($ajuan->kades); ?></td>
        </tr>
    </table>

</body>

</html><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/arsip/sk.blade.php ENDPATH**/ ?>