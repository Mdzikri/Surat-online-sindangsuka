
<?php $__env->startSection('judul', 'Antrian Pengajuan Surat'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="container card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="card-category mt-2">Daftar Antrian Pengajuan Surat:</h5>
                            
                            <h4 class="card-title">Antrian Pengajuan</h4>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered">
                            <thead class=" text-primary">
                                <th><b>Pengaju</b></th>
                                <th><b>Surat</b></th>
                                <th><b>Tanggal Ajuan</b></th>
                                <th class="text-right"><b>Opsi</b></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($surat->user->nama); ?></td>
                                <td><b><?php echo e($surat->jenis); ?></b></td>
                                <td><?php echo e($surat->created_at->diffForHumans()); ?></td>
                                <td class="text-right">
                                    <a href="<?php echo e(route('antrian.edit', $surat->id)); ?>" class="badge badge-warning">Buka</a>
                                    
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="container">
                    <?php echo e($antrian->links()); ?> 
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\wanakarya\resources\views/admin/antrian/index.blade.php ENDPATH**/ ?>