
<?php $__env->startSection('judul', 'Daftar Antrian Persetujuan Surat'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="container card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="card-category mt-2">Daftar surat antrian yang pernah di acc atau di tolak:</h5>
                            <h4 class="card-title">Riwayat Surat</h4>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered">
                            <thead class=" text-primary">
                                <th><b>Pengaju</b></th>
                                <th><b>Surat</b></th>
                                <th><b>Diajukan</b></th>
                                <th><b>Ditolak/Diterima</b></th>
                                <th><b>Status</b></th>
                                <th class="text-right"><b>Opsi</b></th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($surat->user->nama); ?></td>
                                <td><?php echo e($surat->jenis); ?></td>
                                <td><?php echo e($surat->created_at->format('d M Y')); ?></td>
                                <td><?php echo e($surat->updated_at->format('d M Y')); ?></td>
                                <td>
                                    <?php if($surat->acc == 1): ?>
                                        <span class="text-success"><b>Diterima</b></span>
                                    <?php elseif($surat->acc == 2): ?>
                                        <span class="text-danger"><b>Ditolak</b></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-right">
                                    <?php if($surat->acc == 1): ?>
                                        <a href="<?php echo e(route('adm.lihat', $surat->id)); ?>" class="badge badge-warning">Lihat</a>
                                    <?php elseif($surat->acc == 2): ?>
                                        <a href="" class="badge badge-warning">Lihat</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/admin/riwayat/index.blade.php ENDPATH**/ ?>