
<?php $__env->startSection('judul', 'Kelola Data Desa'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
          <div class="col-md-7 pr-1">
            <div class="card">
              <div class="card-header">
                <h5 class="title">Edit Data Desa</h5>
              </div>
              <div class="card-body">
                <?php if(isset($desa)): ?>
                <form action="<?php echo e(route('desa.store')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                    <div class="">
                      <div class="form-group">
                        <label>Nama Desa</label>
                        <input type="text" name="nama_desa" class="form-control" value="<?php echo e(old('nama_desa') ?? $desa->nama_desa); ?>">
                        <?php $__errorArgs = ['nama_desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="">
                      <div class="form-group">
                        <label>Kecamatan</label>
                        <input type="text" name="kecamatan" class="form-control" value="<?php echo e(old('kecamatan') ?? $desa->kecamatan); ?>">
                        <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="">
                      <div class="form-group">
                        <label>Kabupaten</label>
                        <input type="text" name="kabupaten" class="form-control" value="<?php echo e(old('kabupaten') ?? $desa->kabupaten); ?>">
                        <?php $__errorArgs = ['kabupaten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="">
                      <div class="form-group">
                        <label>Alamat Kantor Desa</label>
                        <input type="text" name="alamat_kantor" class="form-control" value="<?php echo e(old('alamat_kantor') ?? $desa->alamat_kantor); ?>">
                        <?php $__errorArgs = ['alamat_kantor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  <button type="submit" class="btn btn-primary my-3">Ubah</button>
                </form>
                <?php else: ?>
                <form action="<?php echo e(route('desa.store')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                    <div class="">
                      <div class="form-group">
                        <label>Nama Desa</label>
                        <input type="text" name="nama_desa" class="form-control">
                        <?php $__errorArgs = ['nama_desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="">
                      <div class="form-group">
                        <label>Kecamatan</label>
                        <input type="text" name="kecamatan" class="form-control">
                        <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="">
                      <div class="form-group">
                        <label>Kabupaten</label>
                        <input type="text" name="kabupaten" class="form-control">
                        <?php $__errorArgs = ['kabupaten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="">
                      <div class="form-group">
                        <label>Alamat Kantor Desa</label>
                        <input type="text" name="alamat_kantor" class="form-control">
                        <?php $__errorArgs = ['alamat_kantor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  <button type="submit" class="btn btn-primary my-3">Ubah</button>
                </form> 
                <?php endif; ?>
              </div>
            </div>
          </div>

          <?php if(isset($desa)): ?>
            <div class="col-md-5 pl-1">
                <div class="card card-logo">
                <div class="card-body">
                <form action="<?php echo e(route('desa.logo', $desa->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo method_field('patch'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="">
                        <label for="logo_desa">Logo Desa</label> <br>
                        <img src="<?php echo e(asset('images/'.$desa->logo_desa.'')); ?>" alt="Logo Desa" class="img-thumbnail mb-2" width="180px">
                        <input type="file" id="logo_desa" name="logo_desa" value="">

                        <?php if('$desa->logo_desa'): ?>
                        <small class="form-text text-muted">Klik tombol diatas untuk mengganti logo Desa.</small>
                        <?php else: ?>
                        <small class="form-text text-muted">Tambahkan Logo Desa.</small>
                        <?php endif; ?>

                        <?php $__errorArgs = ['logo_desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn btn-primary my-3">Simpan</button>
                    </form>
                </div>
                </div>
            </div>
          <?php endif; ?>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\wanakarya\resources\views/super/desa/index.blade.php ENDPATH**/ ?>