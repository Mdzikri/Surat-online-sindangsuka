

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="py-5 text-center">
        <h2 class="orenjudul">Pengajuan SKCK</h2>
        <p class="birusubjudul">Untuk pengajuan SKCK, Harap isikan data dibawah ini sesuai dengan data pribadi anda.</p>
      </div>

    <div class="row">
      <?php echo $__env->make('layouts.partials.identitas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="col-md-7">
        <h4 class="mb-3">Isi Data Lainnya</h4>
        <form action="<?php echo e(route('skck.store')); ?>" method="post" class="needs-validation" novalidate>
           <?php echo csrf_field(); ?> 
            <div class="mb-3">
              <label for="keterangan">Keperluan :</label>
              <textarea class="form-control shadow" name="keterangan" id="keterangan" cols="10" rows="3" placeholder="isi pesan keterangan sesuai kebutuhan. contoh: SKCK untuk ke Polres Garut, untuk untuk keperluan daftar pekerjaan. tanggal 28 Oktober"></textarea>
              <div class="invalid-feedback">
                wajib diisi.
              </div>
            </div>

          <hr class="mb-4">
          <button class="btn btn-primary btn-lg btn-block tombol shadow" type="submit" name="translate">Ajukan Permohonan Surat</button>
        </form>
      </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\suratliwire\resources\views/skck/create.blade.php ENDPATH**/ ?>