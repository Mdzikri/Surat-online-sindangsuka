<div class="kop">
    <p>PEMERINTAH KABUPATEN GARUT<br>KECAMATAN CIBATU<br>DESA SINDANGSUKA</p>
</div><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/layouts/partials/kop.blade.php ENDPATH**/ ?>