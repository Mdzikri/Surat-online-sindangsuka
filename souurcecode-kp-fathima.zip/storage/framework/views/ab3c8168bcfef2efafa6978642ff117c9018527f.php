

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="py-5 text-center">
        <h2 class="orenjudul">Pengajuan Surat Domisili</h2>
        <p class="birusubjudul">Untuk pengajuan Surat Domisili, Harap isikan data dibawah ini sesuai dengan data pribadi anda.</p>
      </div>

    <div class="row">
    <?php echo $__env->make('layouts.partials.identitas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="col-md-7">
        <h4 class="mb-3">Isi Data Lainnya</h4>
        <form action="" method="post" class="needs-validation" novalidate>
            
            <div class="mb-3">
              <label for="keperluan">Keterangan :</label>
              <textarea class="form-control shadow" name="keperluan" id="keperluan" cols="10" rows="3" placeholder="Harap isikan keperluan. contoh: untuk perlengkapan administrasi"></textarea>
              <div class="invalid-feedback">
                wajib diisi.
              </div>
            </div>

          

          <hr class="mb-4">
          <button class="btn btn-primary btn-lg btn-block tombol shadow" type="submit" name="translate">Ajukan Permohonan Surat</button>
        </form>
      </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\suketv7\resources\views/sd/create.blade.php ENDPATH**/ ?>