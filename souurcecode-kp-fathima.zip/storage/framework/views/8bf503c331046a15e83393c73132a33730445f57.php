

<?php $__env->startSection('content'); ?>
    <div class="container my-5">
      <div class="row">
        <div class="col-sm-3 col-md-3">
            <h1>Lengkapi Data Diri</h1>
            <p><i>Lengkapi data diri anda seperti no. telp, penghasilan, foto ktp, foto kartu keluarga, dan pas foto untuk syarat kebutuhan pengajuan surat tertentu.</i></p>
        </div>
        <div class="col-sm-5 col-md-5">
          
            <form action="<?php echo e(route('lengkapi.update')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="container row">
                <div class="col-md-5 pr-1 pl-1">
                  <div class="form-group">
                    <label for="telp">No Telp/WhatsApp</label>
                    <input type="number" class="form-control" id="telp" name="telp" value="<?php echo e($user->telp ?? $user->telp); ?>">
                    <?php $__errorArgs = ['telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-7 pr-1 pl-1">
                  <div class="form-group">
                    <label for="penghasilan">Penghasilan</label>
                    <select class="form-control" id="penghasilan" name="penghasilan">
                      <?php if($user->penghasilan): ?>
                      <option value="<?php echo e($user->penghasilan ?? $user->penghasilan); ?>"><?php echo e($user->penghasilan); ?></option>
                      <?php endif; ?>
                      <option value="< 1.000.000"> < 1.000.000 </option>
                      <option value="1.000.000 sd. 3.000.000">1.000.000 sd. 3.000.000</option>
                      <option value="3.000.000 sd. 5.000.000">3.000.000 sd. 5.000.000</option>
                      <option value="5.000.000 sd. 10.000.000">5.000.000 sd. 10.000.000</option>
                      <option value="> 10.000.000"> > 10.000.000 </option>
                    </select>
                    <?php $__errorArgs = ['penghasilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label for="fotoktp">Foto KTP</label>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lengkap')): ?>
                <img src="<?php echo e(asset('images/fotoktp/'.$user->fotoktp.'')); ?>" alt="Foto KTP <?php echo e($user->nama); ?>" class="img-thumbnail" width="180px">
                <?php endif; ?>
                <input type="file" class="form-control-file" id="fotoktp" name="fotoktp" value="<?php echo e($user->fotoktp ?? $user->fotoktp); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lengkap')): ?>
                <small class="form-text text-muted">Klik tombol diatas untuk mengganti foto KTP Anda.</small>
                <?php else: ?>
                <small class="form-text text-muted">Tambahkan foto KTP atau scan foto KTP.</small>
                <?php endif; ?>
                <?php $__errorArgs = ['fotoktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group">
                <label for="fotokk">Foto KK</label>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lengkap')): ?>
                <img src="<?php echo e(asset('images/fotokk/'.$user->fotokk.'')); ?>" alt="Foto KK <?php echo e($user->nama); ?>" class="img-thumbnail" width="180px">
                <?php endif; ?>
                <input type="file" class="form-control-file" id="fotokk" name="fotokk" value="<?php echo e($user->fotokk ?? $user->fotokk); ?>">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lengkap')): ?>
                <small class="form-text text-muted">Klik tombol diatas untuk mengganti foto KTP Anda.</small>
                <?php else: ?>
                <small class="form-text text-muted">Tambahkan foto kartu Keluarga atau scan foto kartu keluarga.</small>
                <?php endif; ?>
                <?php $__errorArgs = ['fotokk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lengkap')): ?>
                <button class="btn tombol shadow" type="submit" name="translate">Edit Kelengkapan</button>
                <?php else: ?>
                <button class="btn tombol shadow" type="submit" name="translate">Lengkapi</button>
                <?php endif; ?>
              </div>
              <br>
            </form>
        </div>
        <div class="col-sm-4 col-md-4">
            <div class="card mt-1 px-3 py-4">
                <h4 class="d-flex justify-content-between align-items-center mb-3">
                  <span class="text-muted">Identitas Diri</span>
                  <a href="<?php echo e(route('edit.profil')); ?>" class="btn btn-secondary rounded-pill tomboledit">Edit</a>
                </h4>
                <ul class="list-group mb-3 shadow">
                  <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <div>
                      <h6 class="my-0">Nama Lengkap</h6>
                    </div>
                    <span class="text-muted"><?php echo e(Auth::user()->nama); ?></span>
                  </li>
                  <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <div>
                      <h6 class="my-0">NIK</h6>
                    </div>
                    <span class="text-muted"><?php echo e(Auth::user()->nik); ?></span>
                  </li>
                  <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <div>
                      <h6 class="my-0">Tempat, Tanggal Lahir</h6>
                    </div>
                    <span class="text-muted text-right"><?php echo e(Auth::user()->ttl); ?></span>
                  </li>
                  <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <div>
                      <h6 class="my-0">Jenis Kelamin</h6>
                    </div>
                    <span class="text-muted"><?php echo e(Auth::user()->jk); ?></span>
                  </li>
                  <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <div>
                      <h6 class="my-0">Status</h6>
                    </div>
                    <span class="text-muted"><?php echo e(Auth::user()->status); ?></span>
                  </li>
                  <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <div>
                      <h6 class="my-0">Agama</h6>
                    </div>
                    <span class="text-muted"><?php echo e(Auth::user()->agama); ?></span>
                  </li>
                  <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <div>
                      <h6 class="my-0">Pekerjaan</h6>
                    </div>
                    <span class="text-muted"><?php echo e(Auth::user()->pekerjaan); ?></span>
                  </li>
                  <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <div>
                      <h6 class="my-0">Alamat</h6>
                    </div>
                    <span class="text-muted text-right"><?php echo e(Auth::user()->alamat); ?></span>
                  </li>
                  <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <div>
                      <h6 class="my-0">Kewarganegaraan</h6>
                    </div>
                    <span class="text-muted"><?php echo e(Auth::user()->kewarganegaraan); ?></span>
                  </li>
                </ul>
            </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\wanakarya\resources\views/user/lengkapi-profil.blade.php ENDPATH**/ ?>