<div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light costum-nav px-4 py-3 shadow">
      <a class="navbar-brand" href="#">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo kabupaten garut">
        <span>Suket Online</span>
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('skck.create')); ?>">SKCK</a>
          </li>
          <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
            </li>
          <?php else: ?>
              <li class="nav-item dropdown">
                  <a id="navbarDropdown" class="tombol nav-link dropdown-toggle shadow" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                      <?php echo e(Auth::user()->nama); ?>

                  </a>
                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                         onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();">
                          Keluar
                      </a>
                      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                          Edit Profil
                      </a>
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                          <?php echo csrf_field(); ?>
                      </form>
                  </div>
              </li>
          <?php endif; ?>
        </ul>
      </div>
    </nav>
</div>
<?php /**PATH C:\Users\Fathima Umar\Desktop\suratliwire\resources\views/livewire/navsuper.blade.php ENDPATH**/ ?>