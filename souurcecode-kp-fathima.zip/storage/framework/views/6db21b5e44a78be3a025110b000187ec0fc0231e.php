

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="py-5 text-center">
        <h2 class="orenjudul">Formulir Permohonan Kartu Tanda Penduduk</h2>
        <p class="birusubjudul">Untuk pengajuan Surat Keterangan Beda Nama, Harap isikan data dibawah ini sesuai dengan data pribadi anda.</p>
      </div>

    <div class="row">
      <?php echo $__env->make('layouts.partials.identitas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="col-md-7">
        <h4 class="mb-3">Isi Data Lainnya</h4>
        <form action="<?php echo e(route('store')); ?>" method="post" class="needs-validation" novalidate>
          <?php echo csrf_field(); ?>
            <input type="hidden" name="jenis" value="Formulir Permohonan KTP">
            <div class="mb-3">
                <label for="jenis_permohonan" class="">Jenis Permohonan</label>
                <div class="">
                    <select name="jenis_permohonan" class="custom-select d-block w-100 select" id="jenis_permohonan">
                      <option value="Baru">Baru</option>
                      <option value="Perpanjangan">Perpanjangan</option>
                      <option value="Penggantian">Penggantian</option>
                    </select>
                    <?php $__errorArgs = ['jenis_permohonan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4 pr-1 pr-1">
                    <label for="no_kk">No KK :</label>
                    <input name="no_kk" type="text" class="form-control shadow" id="no_kk" placeholder="contoh: 320402482359828" required>
                    <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4 pr-1 pr-1">
                    <label for="nama_kk">Nama KK :</label>
                    <input name="nama_kk" type="text" class="form-control shadow" id="nama_kk" placeholder="Nama pada KK" required>
                    <?php $__errorArgs = ['nama_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4 pr-1 pr-1">
                    <label for="kode_pos">Kode Pos :</label>
                    <input name="kode_pos" type="text" class="form-control shadow" id="kode_pos" placeholder="contoh: 40393" required>
                    <?php $__errorArgs = ['kode_pos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="mb-3">
              <label for="keterangan">Keperluan :</label>
              <textarea class="form-control shadow" name="keterangan" id="keterangan" cols="10" rows="3" placeholder="Cantumkan keperluan, contoh: Perlengkapan Administrasi. dan pesan lainnya (jika ada)."></textarea>
              <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          <hr class="mb-4">
          <button class="btn btn-lg btn-block tombol shadow" type="submit" name="translate">Ajukan Permohonan Surat</button>
        </form>
      </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\wanakarya\resources\views/form-ajuan/mohon-ktp.blade.php ENDPATH**/ ?>