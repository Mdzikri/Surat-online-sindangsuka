
<?php $__env->startSection('judul', 'Kelola Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
    <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">
                        RW Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?> <a href="" data-toggle="modal" data-target="#infoAdmin"><i class="fas fa-info-circle mt-3"></i></a>
                    </h4>
                    <a href="" data-toggle="modal" data-target="#tambahRw" class="btn btn-primary">Tambah</a>
                     <!-- Modal Tambah RW -->
                      <div class="modal fade" id="tambahRw" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Tambah RW</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <p class="text-center">Tambah RT</p>
                              <small class="text-secondary">Tambah RT pada Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?>.</small>
                              <form action="<?php echo e(route('rw.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                  <div class="col-md-6 pr-1">
                                    <div class="form-group">
                                      <label for="no">RW</label>
                                      <input type="text" class="form-control" id="no" name="no"placeholder="contoh: 01">
                                      <?php $__errorArgs = ['no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> <div>        
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                  </div>
                                  <div class="col-md-6 pl-1">
                                    <div class="form-group">
                                      <label for="ketua">NIK Ketua RW</label>
                                      <input type="text" class="form-control" id="ketua" name="ketua" placeholder="NIK Ketua RW">
                                      <?php $__errorArgs = ['ketua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                  </div>
                                </div>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
                                <button class="btn btn-info" type="submit">Tambah</button>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                </div>
                <h5 class="card-category mt-2">Daftar Admin Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="table table-striped table-bordered">
                        <thead class="text-primary">
                            <th><b>RW</b></th>
                            <th><b>Ketua</b></th>
                            <th class="text-right"><b>Opsi</b></th> 
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $rw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($w->no); ?></td>
                            <td><?php echo e($w->ketua); ?></td>
                            <td class="text-right" width="15%">
                                <a href="" data-toggle="modal" data-target="#editRw<?php echo e($w->id); ?>" class="badge badge-info">Edit</a>
                                <!-- Modal Edit RW -->
                                <div class="modal fade" id="editRw<?php echo e($w->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Edit RW</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                        <p class="text-center">Anda yakin ingin mengedit RW <i><?php echo e($w->no); ?></i> ?</p>
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
                                        <form action="<?php echo e(route('rw.update', $w->id)); ?>" method="post">
                                          <?php echo csrf_field(); ?>
                                          <?php echo method_field('patch'); ?>
                                          <button class="btn btn-info" type="submit">Edit</button>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                
                                <!-- Modal Hapus RW -->
                                <div class="modal fade" id="hapusRw<?php echo e($w->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus RW</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                        <p class="text-center">Anda yakin ingin menghapus <i><b>RW.<?php echo e($w->no); ?></b></i> ?</p>
                                        <small class="text-secondary">*tindakan ini akan membuat RW.<?php echo e($w->no); ?> tidak terdaftar lagi di Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?></small>
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
                                        <form action="<?php echo e(route('rw.delete', $w->id)); ?>" method="post">
                                          <?php echo csrf_field(); ?>
                                          <?php echo method_field('delete'); ?>
                                          <button class="btn btn-danger" type="submit">Hapus</button>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="container card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">
                        RT Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?><a href="" data-toggle="modal" data-target="#infoAdmin"><i class="fas fa-info-circle mt-3"></i></a>
                    </h4>
                    <a href="" data-toggle="modal" data-target="#tambahRt" class="btn btn-primary" href="<?php echo e(route('admin.create')); ?>">Tambah</a>
                     <!-- Modal Tambah RT -->
                    <div class="modal fade" id="tambahRt" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Tambah RT</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <p class="text-center">Tambah RT</p>
                              <small class="text-secondary">Tambah RT pada Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?>.</small>
                              <form action="<?php echo e(route('rt.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                  <div class="col-md-6 pr-1">
                                    <div class="form-group">
                                        <label for="rw_id" class="">Pilih RW</label>
                                        <div class="">
                                            <select name="rw_id" class="custom-select d-block w-100 select" id="rw_id">
                                              <?php $__currentLoopData = $rw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($w->id); ?>">RW. <?php echo e($w->no); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['rw_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                  </div>
                                  <div class="col-md-6 pl-1">
                                    <div class="form-group">
                                      <label for="no">RT</label>
                                      <input type="text" class="form-control" id="no" name="no" placeholder="Contoh: 03">
                                      <?php $__errorArgs = ['no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label for="ketua">NIK Ketua RT</label>
                                  <input type="text" class="form-control" id="ketua" name="ketua" placeholder="Contoh: 03">
                                  <?php $__errorArgs = ['ketua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
                                <button class="btn btn-info" type="submit">Tambah</button>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                </div>
                <h5 class="card-category mt-2">Daftar RT Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="table table-striped table-bordered">
                        <thead class="text-primary">
                            <th><b>RT</b></th>
                            <th><b>RW</b></th>
                            <th><b>Ketua</b></th>
                            <th class="text-right" width="15%"><b>Opsi</b></th> 
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $rt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($t->no); ?></td>
                            <td><?php echo e($t->rw->no); ?></td>
                            <td><?php echo e($t->ketua); ?></td>
                            <td class="text-right">
                                <a href="" data-toggle="modal" data-target="#editRt<?php echo e($t->id); ?>" class="badge badge-info">Edit</a>
                                <!-- Modal Edit RT -->
                                <div class="modal fade" id="editRt<?php echo e($t->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Edit RT</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                        <p class="text-center">Anda yakin ingin menghapus izin <b>Admin</b> dari <i><?php echo e($t->no); ?></i> ?</p>
                                        <small class="text-secondary">*tindakan ini akan membuat <?php echo e($t->no); ?> tidak memiliki akses untuk mengelola Website Desa <?php echo e(isset($desa) ? $desa->nama_desa : '*atur nama desa'); ?> lagi.</small>
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
                                        <form action="<?php echo e(route('rt.update', $t->id)); ?>" method="post">
                                          <?php echo csrf_field(); ?>
                                          <?php echo method_field('patch'); ?>
                                          <button class="btn btn-info" type="submit">Edit</button>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                
                                <!-- Modal Hapus RT -->
                                <div class="modal fade" id="hapusRt<?php echo e($t->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus RT</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                        <p class="text-center">Anda yakin ingin menghapus <i><b>RT.<?php echo e($t->no); ?>/Rw.<?php echo e($t->rw->no); ?></b></i> ?</p>
                                        <small class="text-secondary">*tindakan ini akan membuat RT.<?php echo e($t->no); ?> tidak terdaftar lagi di RW.<?php echo e($t->rw->no); ?></small>
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
                                        <form action="<?php echo e(route('admin.delete', $t->id)); ?>" method="post">
                                          <?php echo csrf_field(); ?>
                                          <?php echo method_field('delete'); ?>
                                          <button class="btn btn-danger" type="submit">Hapus</button>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Info Admin -->
<div class="modal fade" id="infoAdmin" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Role Admin</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Level user yang mempunyai kewenangan sebagai berikut:
        <ul>
          <li>menyetujui dan menolak surat pengajuan,</li>
          <li>mengelola pengguna,</li>
          <li>mengelola pesan dan keterangan surat,</li>
          <li>mengelola riwayat pengajuan,</li>
          <li>dan mengelola arsip surat.</li>
        </ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Info Super Admin -->
<div class="modal fade" id="infoSuperAdmin" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Role Super Admin</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\wanakarya\resources\views/super/rt-rw/index.blade.php ENDPATH**/ ?>