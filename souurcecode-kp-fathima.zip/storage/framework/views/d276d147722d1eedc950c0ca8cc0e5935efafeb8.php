
<?php $__env->startSection('judul', 'Kelola Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="container card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">
                        Admin <a href="" data-toggle="modal" data-target="#infoAdmin"><i class="fas fa-info-circle mt-3"></i></a>
                    </h4>
                    <a type="button" class="btn btn-primary" href="<?php echo e(route('admin.create')); ?>">Tambah</a>
                </div>
                <h5 class="card-category mt-2">Daftar Admin Desa Sindangsuka</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="table table-striped table-bordered">
                        <thead class="text-primary">
                            <th><b>Nama Admin</b></th>
                            <th><b>Rt/Rw</b></th>
                            <th class="text-right"><b>Opsi</b></th> 
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($adm->nama); ?></td>
                            <td><?php echo e($adm->rt_rw); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('user.show', $adm->id)); ?>" class="badge badge-info">Lihat</a>
                                <a href="" data-toggle="modal" data-target="#hapusAdmin<?php echo e($adm->id); ?>" class="badge badge-danger">Hapus</a>
                                <!-- Modal Hapus Admin -->
                                <div class="modal fade" id="hapusAdmin<?php echo e($adm->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus Admin</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                        <p class="text-center">Anda yakin ingin menghapus izin <b>Admin</b> dari <i><?php echo e($adm->nama); ?></i> ?</p>
                                        <small class="text-secondary">*tindakan ini akan membuat <?php echo e($adm->nama); ?> tidak memiliki akses untuk mengelola Website Desa Sindangsuka lagi.</small>
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
                                        <form action="<?php echo e(route('admin.delete', $adm->id)); ?>" method="post">
                                          <?php echo csrf_field(); ?>
                                          <?php echo method_field('delete'); ?>
                                          <button class="btn btn-danger" type="submit">Hapus</button>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
    
</div>

<!-- Modal Info Admin -->
<div class="modal fade" id="infoAdmin" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Role Admin</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Level user yang mempunyai kewenangan sebagai berikut:
        <ul>
          <li>menyetujui dan menolak surat pengajuan,</li>
          <li>mengelola pengguna,</li>
          <li>mengelola pesan dan keterangan surat,</li>
          <li>mengelola riwayat pengajuan,</li>
          <li>dan mengelola arsip surat.</li>
        </ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Info Super Admin -->
<div class="modal fade" id="infoSuperAdmin" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Role Super Admin</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/super/admin/index.blade.php ENDPATH**/ ?>