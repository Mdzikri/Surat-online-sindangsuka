
<?php $__env->startSection('judul', 'Detail User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
          <div class="col-md-6 order-md-2 pl-1">
            <div class="card">
              <div class="card-header">
                <h5 class="title">Edit Data <?php echo e($user->nama); ?></h5>
              </div>
              <div class="card-body">
                <form action="<?php echo e(route('user.update', $user->id)); ?>" method="post">
                    <?php echo method_field('patch'); ?>
                    <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label>No NIK</label>
                        <input type="text" name="nik" class="form-control" value="<?php echo e(old('nik') ?? $user->nik); ?>">
                        <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="col-md-6 pl-1">
                      <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama') ?? $user->nama); ?>">
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label>Tempat, Tanggal Lahir</label>
                        <input type="text" name="ttl" class="form-control" value="<?php echo e(old('ttl') ?? $user->ttl); ?>">
                        <?php $__errorArgs = ['ttl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="col-md-6 pl-1">
                      <div class="">
                        <label>Jenis Kelamin</label>
                        <select class="form-control" id="exampleFormControlSelect1" name="jk" value="<?php echo e(old('jk') ?? $user->jk); ?>">
                          <option value="<?php echo e($user->jk); ?>"><?php echo e($user->jk); ?></option>
                          <option value="Laki-laki">Laki-laki</option>
                          <option value="Perempuan">Perempuan</option>
                        </select>
                        <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-5 pr-1">
                      <div class="form-group">
                        <label>Pekerjaan</label>
                        <input type="text" name="pekerjaan" class="form-control" value="<?php echo e(old('pekerjaan') ?? $user->pekerjaan); ?>">
                        <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="col-md-3 px-1">
                      <div class="form-group">
                        <label>Agama</label>
                        <input type="text" name="agama" class="form-control" value="<?php echo e(old('agama') ?? $user->agama); ?>">
                        <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="col-md-4 pl-1">
                      <div class="">
                        <label for="exampleInputEmail1">Status</label>
                        <select class="form-control" id="exampleFormControlSelect1" name="status" value="<?php echo e(old('status') ?? $user->status); ?>">
                          <option value="<?php echo e(old('status') ?? $user->status); ?>"><?php echo e(old('status') ?? $user->status); ?></option>
                          <option value="Menikah">Menikah</option>
                          <option value="Belum Menikah">Belum Menikah</option>
                          <option value="Janda">Janda</option>
                          <option value="Duda">Duda</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Alamat</label>
                        <input type="text" name="alamat" class="form-control" value="<?php echo e(old('alamat') ?? $user->alamat); ?>">
                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4 pr-1">
                      <div class="form-group">
                        <label for="rt_id" class="">RT</label>
                        <div class="">
                            <select name="rt_id" class="custom-select d-block w-100 select" id="rt_id">
                            <?php $__currentLoopData = $rt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t->id); ?>">RT.<?php echo e($t->no); ?>/RW.<?php echo e($t->rw->no); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['rt_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 pr-1">
                      <div class="form-group">
                        <label for="rw_id" class="">RW</label>
                        <div class="">
                            <select name="rw_id" class="custom-select d-block w-100 select" id="rw_id">
                            <?php $__currentLoopData = $rw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($w->id); ?>">RW.<?php echo e($w->no); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['rw_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 px-1">
                      <div class="form-group">
                        <label>Kewarganegaraan</label>
                        <input type="text" name="kewarganegaraan" class="form-control" value="<?php echo e(old('kewarganegaraan') ?? $user->kewarganegaraan); ?>">
                        <?php $__errorArgs = ['kewarganegaraan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"> <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 pl-1">
                    <div class="form-group mt-2">
                      <button type="submit" class="btn btn-primary ml-2 my-3 allign-right">Edit Identitas</button>
                    </div>
                  </div>

                </form>
              </div>
            </div>
          </div>
          <div class="col-md-6 order-md-1 pr-1">
            <div class="card card-user">
              <div class="card-body">
                <h5 class="title text-center">Data Identitas</h5>
                <table border="0" align="center" width=83% style="padding-left: 30px;">
                    <tr>
                        <td class="text-secondary" width=28%>Nama</td>
                        <td class="text-secondary">:</td>
                        <td style="text-transform: uppercase;"><?php echo e($user->nama); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">No NIK</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($user->nik); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Tempat Tgl Lahir</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($user->ttl); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Agama</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($user->agama); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Jenis Kelamin</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($user->jk); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Status</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($user->status); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Pekerjaan</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($user->pekerjaan); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Penduduk Rt/Rw</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($user->rt->no); ?>/<?php echo e($user->rw->no); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Alamat</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($user->alamat); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Kewarganegaraan</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($user->kewarganegaraan); ?></td>
                    </tr>
                </table>

                <h5 class="title text-center mt-4">Data Kelengkapan</h5>
                <?php if($user->status_lengkap == 1): ?>
                <table border="0" align="center" width=83% style="padding-left: 30px;">
                    <tr>
                        <td class="text-secondary" width=28%>No Telp</td>
                        <td class="text-secondary">:</td>
                        <td style="text-transform: uppercase;"><?php echo e($user->telp); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Penghasilan</td>
                        <td class="text-secondary">:</td>
                        <td><?php echo e($user->penghasilan); ?></td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Foto KTP</td>
                        <td class="text-secondary">:</td>
                        <td>
                          <img src="<?php echo e(asset('images/fotoktp/'.$user->fotoktp.'')); ?>" alt="Foto KTP <?php echo e($user->nama); ?>" class="img-thumbnail" width="180px">
                        </td>
                    </tr>
                    <tr>
                        <td class="text-secondary">Foto KK</td>
                        <td class="text-secondary">:</td>
                        <td>
                          <img src="<?php echo e(asset('images/fotokk/'.$user->fotokk.'')); ?>" alt="Foto KK <?php echo e($user->nama); ?>" class="img-thumbnail" width="180px">
                        </td>
                    </tr>
                </table>
                <?php else: ?>
                <div class="d-flex justify-content-center">
                    <small class="">*User belum melengkapi data kelengkapan</small>
                </div>
                <?php endif; ?>
              </div>
              <hr>
              <div class="button-container">
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#hapusUser">Non-Aktifkan User</button>
              </div>
            </div>
          </div>
        </div>
      </div>


<!-- Modal -->
<div class="modal fade" id="hapusUser" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Non-Aktifkan User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
         Anda yakin ingin menonaktifkan <b><?php echo e($user->nama); ?></b> sebagai user di website layanan surat Desa? <br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batalkan</button>
        <form action="<?php echo e(route('user.delete', $user->id)); ?>" method="post" class="d-inline">
          <?php echo csrf_field(); ?>
          <?php echo method_field('delete'); ?>
          <button type="submit" class="btn btn-danger">Non-aktifkan</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\wanakarya\resources\views/admin/user/show.blade.php ENDPATH**/ ?>