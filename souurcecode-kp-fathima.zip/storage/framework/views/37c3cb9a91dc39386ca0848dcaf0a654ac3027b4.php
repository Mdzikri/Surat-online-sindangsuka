<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>


    <title>Suket Desa Sindangsuka</title>
  </head>
  <body>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navsuper', [])->html();
} elseif ($_instance->childHasBeenRendered('abIi04n')) {
    $componentId = $_instance->getRenderedChildComponentId('abIi04n');
    $componentTag = $_instance->getRenderedChildComponentTagName('abIi04n');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('abIi04n');
} else {
    $response = \Livewire\Livewire::mount('navsuper', []);
    $html = $response->html();
    $_instance->logRenderedChild('abIi04n', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <div class="">
    <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer class="my-5 text-muted text-center text-small">
      <p class="mb-1">&copy; 2020 - PKM UIN-Desa Sindang Suka</p>
      <ul class="list-inline">
        <li class="list-inline-item"><a href="#">Privacy</a></li>
        <li class="list-inline-item"><a href="#">Terms</a></li>
        <li class="list-inline-item"><a href="#">Support</a></li>
      </ul>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\Users\Fathima Umar\Desktop\suratliwire\resources\views/layouts/super.blade.php ENDPATH**/ ?>