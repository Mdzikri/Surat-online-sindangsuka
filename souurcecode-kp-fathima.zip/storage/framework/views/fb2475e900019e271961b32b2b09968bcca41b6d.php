

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="py-5 text-center">
        <h2 class="orenjudul">Data Surat Kematian</h2>
        <p class="birusubjudul">Harap isikan data dibawah ini sesuai dengan data Almarhum.</p>
      </div>

    <div class="row">
      <div class="identitas col-md-5 mb-4">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-muted">Identitas Pelapor</span>
        </h4>
        <ul class="list-group mb-3 shadow">
          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <h6 class="my-0">Nama Lengkap</h6>
            </div>
            <span class="text-muted"><?php echo e(Auth::user()->nama); ?></span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <h6 class="my-0">Tempat, Tanggal Lahir</h6>
            </div>
            <span class="text-muted"><?php echo e(Auth::user()->ttl); ?></span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <h6 class="my-0">Pekerjaan</h6>
            </div>
            <span class="text-muted"><?php echo e(Auth::user()->pekerjaan); ?></span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-condensed">
            <div>
              <h6 class="my-0">Alamat</h6>
            </div>
            <span class="text-muted"><?php echo e(Auth::user()->alamat); ?></span>
          </li>
        </ul>
      <form action="<?php echo e(route('store')); ?>" method="post" class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="jenis" value="Surat Kematian">
        <input type="hidden" name="keterangan" value="-">
        <div class="mb-3">
            <label for="hubungan">Hubungan pelapor dengan yang meninggal :</label>
            <input name="hubungan" type="text" class="form-control shadow" id="hubungan" placeholder="contoh: Keluarga">
            <?php $__errorArgs = ['hubungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="col-md-7">
          <div class="row">
            <div class="col-md-6">
              <h4 class="mb-3">Identitas Almarhum</h4>
              <div class="mb-3">
                <label for="nama_alm">Nama Lengkap :</label>
                <input name="nama_alm" type="text" class="form-control shadow" id="nama_alm" placeholder="">
                <?php $__errorArgs = ['nama_alm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="mb-3">
                <label for="jk_alm">Jenis Kelamin :</label>
                <select name="jk_alm" class="custom-select d-block w-100 select shadow" id="jk_alm">
                  <option value="Laki-laki">Laki-laki</option>
                  <option value="Perempuan">Perempuan</option>
                </select>
                <?php $__errorArgs = ['jk_alm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="mb-3">
                <label for="umur_alm">Umur :</label>
                <input name="umur_alm" type="text" class="form-control shadow" id="umur_alm" placeholder="">
                <?php $__errorArgs = ['umur_alm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="mb-3">
                <label for="agama_alm">Agama :</label>
                <input name="agama_alm" type="text" class="form-control shadow" id="agama_alm" placeholder="">
                <?php $__errorArgs = ['agama_alm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="mb-3">
                <label for="alamat_alm">Alamat :</label>
                <input name="alamat_alm" type="text" class="form-control shadow" id="alamat_alm" placeholder="">
                <?php $__errorArgs = ['alamat_alm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div class="col-md-6">
              <h4 class="mb-3">Telah Meninggal Dunia Pada :</h4>
              <div class="mb-3">
                <label for="hari">Hari :</label>
                <input name="hari" type="text" class="form-control shadow" id="hari" placeholder="">
                <?php $__errorArgs = ['hari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="mb-3">
                <label for="tanggal">Tanggal :</label>
                <input name="tanggal" type="text" class="form-control shadow" id="tanggal" placeholder="">
                <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="mb-3">
                <label for="pukul">Pukul :</label>
                <input name="pukul" type="text" class="form-control shadow" id="pukul" placeholder="">
                <?php $__errorArgs = ['pukul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="mb-3">
                <label for="tempat">Bertempat di :</label>
                <input name="tempat" type="text" class="form-control shadow" id="tempat" placeholder="">
                <?php $__errorArgs = ['tempat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="mb-3">
                <label for="penyebab">Penyebab Kematian :</label>
                <input name="penyebab" type="text" class="form-control shadow" id="penyebab" placeholder="contoh: sakit">
                <?php $__errorArgs = ['penyebab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1" > <small><?php echo e($message); ?></small> </div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
          <hr class="mb-4">
          <button class="btn btn-lg btn-block tombol shadow" type="submit" name="translate">Ajukan Permohonan Surat</button>
        </form>
      </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathima Umar\Desktop\suratpdf\resources\views/form-ajuan/sk.blade.php ENDPATH**/ ?>